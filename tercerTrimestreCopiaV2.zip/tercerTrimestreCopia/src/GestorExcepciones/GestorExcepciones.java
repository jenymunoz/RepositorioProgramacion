package GestorExcepciones;

import java.io.*;
import java.util.Scanner;

//Clase que gestiona las excepciones
public class GestorExcepciones {
 public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);

     System.out.print("Ingrese el nombre del archivo (incluyendo la extensión, por ejemplo, texto.txt): ");
     String nombreArchivo = scanner.nextLine();

     File archivo = new File(nombreArchivo);
     String rutaAbsoluta = archivo.getAbsolutePath(); // Obtiene la ruta absoluta del archivo

     try {
         LectorArchivo.leerArchivo(rutaAbsoluta);
     } catch (FileNotFoundException e) {
         System.err.println("Error: El archivo no se encontró en la ruta " + rutaAbsoluta);
     } catch (IOException e) {
         System.err.println("Error: Problema al leer el archivo.");
     } catch (NullPointerException e) {
         System.err.println("Error: Se intentó acceder a un objeto nulo.");
     } finally {
         System.out.println("Proceso finalizado.");
         scanner.close();
     }
 }
}