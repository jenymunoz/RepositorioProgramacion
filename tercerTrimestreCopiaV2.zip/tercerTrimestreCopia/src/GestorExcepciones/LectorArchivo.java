package GestorExcepciones;

import java.io.*;

//Clase que lee el archivo y busca adjetivos prohibidos
class LectorArchivo {
 // Lista de adjetivos prohibidos
 private static final String[] ADJETIVOS_PROHIBIDOS = {"idiota", "granuja", "infeliz", "estúpida"};

 public static void leerArchivo(String rutaArchivo) throws IOException {
     // Crear el archivo a partir de la ruta proporcionada
     File archivo = new File(rutaArchivo);

     // Verificar si el archivo existe y es legible
     //if (!archivo.exists()) {
     //    System.err.println("Error: El archivo no existe en la ruta: " + rutaArchivo);
     //    return;
     //}

     try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
         String linea;
         int numLinea = 0;

         // Leer el archivo línea por línea
         while ((linea = br.readLine()) != null) {
             numLinea++; // Incrementamos el contador para todas las líneas

             try {
                 // Verificar si la línea está vacía o contiene solo espacios (se considera como nula)
                 if (linea.trim().isEmpty()) {
                     System.err.println("Se ha encontrado una línea vacía o nula en la línea " + numLinea);
                     throw new NullPointerException("Se detectó un valor nulo (vacío) en la línea " + numLinea);
                 }

                 // Mostrar la línea leída
                 System.out.println("Leyendo línea " + numLinea + ": " + linea);

                 // Verificar si alguna palabra prohibida está en la línea
                 for (String adjetivo : ADJETIVOS_PROHIBIDOS) {
                     // Usamos un patrón para encontrar la palabra exacta (no como parte de otra palabra)
                     if (linea.toLowerCase().matches(".*\\b" + adjetivo.toLowerCase() + "\\b.*")) {
                         throw new PalabraProhibidaException("Palabra prohibida '" + adjetivo + "' encontrada en la línea " + numLinea + ": " + linea);
                     }
                 }

             } catch (PalabraProhibidaException e) {
                 // Captura la excepción de palabra prohibida y sigue leyendo
                 System.err.println("Excepción detectada: " + e.getMessage());
             } catch (NullPointerException e) {
                 // Captura la excepción de NullPointerException (cuando la línea es vacía o nula) y sigue leyendo
                 System.err.println("Excepción detectada: " + e.getMessage());
             }
         }

         // Mensaje final
         System.out.println("Lectura finalizada.");
     }
 }
}