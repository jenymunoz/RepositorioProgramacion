package GestorExcepciones;

//Excepción personalizada para palabras prohibidas
class PalabraProhibidaException extends Exception {
 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public PalabraProhibidaException(String mensaje) {
     super(mensaje);
 }
}

class numeroProhibidoException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public numeroProhibidoException(String mensaje){
		super(mensaje);
	}
} 
