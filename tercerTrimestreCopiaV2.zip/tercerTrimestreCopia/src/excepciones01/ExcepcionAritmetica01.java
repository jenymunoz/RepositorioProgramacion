package excepciones01;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.Scanner;

public class ExcepcionAritmetica01 {
	
	public static void division01(int a, int b){
		try {
			int division = a / b;
			System.out.println("Resultado de la división:" + division);
		}catch(ArithmeticException e){
			System.out.println("No puedes dividir nada por cero. " + e);
			}finally {
			System.out.println("Si el programa falla por favor ingresa cantidades mayores a cero.");
		}
	}
	
	public static void operacionDesbordamiento(){
		int a = Integer.MAX_VALUE; //Este método sobrepasa el valor del tipo integer por lo que no se puede realizar el loa operación de forma correcta
		int b = 1000000;
		
		System.out.println(a + b);
	}
	
	public static void excepcionNoCapturada(){
		int a = 10;
		int b = 0;
		
		System.out.println(a / b);
	}
	
	public static void exceptionNula(){
		String texto = null;
		try {
			int longitud = texto.length();
			System.out.println("La longitud es: " + longitud);
		} catch(NullPointerException exe){
			System.out.println(exe.getMessage());
		}
	}
	
	public static void exceptionArray(int [] arreglo01){
		Scanner entradaDatos = new Scanner(System.in);
		System.out.print("Ingresa el indice del array al que quieres acceder: ");
		int indice = entradaDatos.nextInt();
		
		try {
			for(int i = 0;i < arreglo01.length; i++){
				System.out.println(arreglo01[indice]);
			}
		}catch(ArrayIndexOutOfBoundsException e){
			System.out.println("No existe el indice al que quieres ingresar. " + e.getMessage());
		}finally {
			System.out.println("Tarea terminada");	
			
		}
		
		entradaDatos.close();
	}
	
	@SuppressWarnings("resource")
	public static void excepCionTrowNew(String texto){
		Scanner entradaDatos = new Scanner(System.in);
		 if(texto == null){ //NOTA este formato para capturar las excepciones también puede usarse con los tipo primitivos
			 throw new NullPointerException("El objeto pasado por parámetro es nulo" + "\n" + "Ingresa un texto nuevo: " + (texto = entradaDatos.next()));
			 //NOTA después de una excepción no se ejecuta más código y por lo tanto aúque está al final texto.length no se motrará la longitud de "texto"
		 }
		 System.out.println(texto.length());
		 
		 entradaDatos.close();
	}
	
	public static void excepcionesArchivos(String nombreArchivo){
		try {
			FileReader archivo = new FileReader(nombreArchivo);
			BufferedReader br = new BufferedReader(archivo);
			System.out.println(br.readLine());
			br.close();
		}catch(IOException e){
			System.out.println("Error de E/S: " + e.getMessage());
		}
	}
	
	/*public static void excepcionesSQL(){
		String url = "https://www.w3schools.com/sql";
		
		/*String usuario = "root";
		
		String contraseña = "password";*/
		
		/*try(Connection conexion = DriverManager.getConnection(url/*,usuario,contraseña)){*/
			/*Statement stmt = conexion.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Customers;");
			while(rs.next()){
				System.out.println("Resultado: " + rs.getString("nombre"));
			}
		}catch(SQLException e){
			System.out.println("La base de datos no fue encontrada: " + e.getMessage());
		}
	}*/
	
	public static void ArchivoNoEncontrado() throws IOException{
		try{
			FileInputStream fis = new FileInputStream("\\src\\archivo01.txt");
			System.out.println("Archivo encontrado");
			fis.close();
		}catch(FileNotFoundException e){
			System.out.println("El archivo no fue encontrado: " + e.getMessage());
		}
		
	}
	
	//En este caso vamos a hacer que se nos pase un número que sea un string que luego vamos a convertir a un int donde vamos a dividirlo dode se comrobará la excepcion nullpointerException y aritmetic exeption
	public static void manejandoDosExcepciones(String numero1, String numero2){
		
		if(numero1 == null || numero2 == null){
			throw new NullPointerException("Uno o ambos datos que ingresaste son nulos. Por favor ingresa un nuevo valor"); 
		}
		
		try{
			int numero01 = Integer.parseInt(numero1);
			int numero02 = Integer.parseInt(numero2);
			System.out.println("El resultado de la operación es: " + (numero01 / numero02));
		}catch(ArithmeticException e){
			System.out.println("Error de división por cero" + e.getMessage());
		}
	}
	
	//TODO Podemos hacer que se nos pase un array de Strings y que el primer control que se pase sea el de si es nulo para después controlar su rango
	public static void manejandoExcepcionesArrays(String [] arreglo01){
		int [] arreglo02 = new int [arreglo01.length];
		for(int i = 0; i < arreglo01.length;i++){
			if(arreglo01[i]==null){
				throw new NullPointerException("Uno de los campos dentro de tu array es nulo, por favor revisalo y vuelve a ejecutar el programa");
			}else {
				System.out.println("Tarea realizada");
			}
			arreglo02[i] = Integer.parseInt(arreglo01[i]);
		}
		for(int j = 0; j < arreglo02.length; j++){
			System.out.print(arreglo02[j] + " ");
		}
	}

	public static void main(String[] args) throws IOException {
		//division01(10,0);
		
		//System.out.println();
		
		//operacionDesbordamiento();
		
		//System.out.println();
		
		//excepcionNoCapturada();
		
		//System.out.println();
		
		//exceptionNula();
		
		//System.out.println();
		
		//int [] arreglo01 = {1,2,3,4,5};
		
		//exceptionArray(arreglo01);
		
		//System.out.println();
		
		//String texto01 = "holaMundo";
		//String texto02 = null;
		
		//excepCionTrowNew(texto01);
		//excepCionTrowNew(texto02);
		
		//System.out.println();
		
		//excepcionesArchivos("C:\\Users\\mello\\eclipse-workspace\\TercerTrimestre\\src\\archivo01.txt"); //Indicar la ruta absoluta funciona
		
		//excepcionesArchivos("archivo01.txt"); //Indicar en solitario genera un error
		
		//excepcionesSQL();
		
		//ArchivoNoEncontrado();
		
		/*String numero = "10"; //NOTA en este caso el dato si se pasa a otro string ese otro objeto tendrá el mismo valor NULO
		manejandoDosExcepciones(numero,"5");*/
		
		String [] arreglo01 = {"1","2","3","4"};
		manejandoExcepcionesArrays(arreglo01);
	}

}
