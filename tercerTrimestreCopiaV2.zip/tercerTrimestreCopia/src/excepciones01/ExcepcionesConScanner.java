package excepciones01;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ExcepcionesConScanner {
	
	public static void validacionNumerica(){
		Scanner entradaDatos = new Scanner (System.in);
		int numero = 0;
		boolean numeroValido = false; //Será true si el número es invalido por ejemplo, un número decimal
		
		while(!numeroValido){
			System.out.println("Ingresa un número entero: ");
			try {
				numero = entradaDatos.nextInt();
				numeroValido = true;
				System.out.println("Número valiado: " + numero);
			}catch(InputMismatchException exe){
				System.out.println("Los números decimales no son válidos");
				entradaDatos.next();
			}
		}
	}
	
	public static void validacionNumerica2(){
		Scanner entradaDatos2 = new Scanner (System.in);
		int numero = 0;
		
		System.out.println("Ingresa un número entero: ");
		
		while(!entradaDatos2.hasNextInt()) {
			try {
				numero = entradaDatos2.nextInt();
			}catch(InputMismatchException exe){
				System.out.println("Los números decimales no son válidos.");
				System.out.print("Ingresa un número entero: ");
				entradaDatos2.next();
			}
		}
		
		//boolean numeroValido = false; //Será true si el número es invalido por ejemplo, un número decimal
		//System.out.print("Ingresa un número entero: ");
		/*if(entradaDatos2.hasNextInt()){
			numero = entradaDatos2.nextInt();
			System.out.println("Correcto!");
		}else {
			System.out.println("Debes ingresar un número entero");
		}*/
		
		/*while(!numeroValido){
			System.out.println("Ingresa un número entero: ");
			try {
				numero = entradaDatos2.nextInt();
				numeroValido = true;
				System.out.println("Número valiado: " + numero);
			}catch(InputMismatchException exe){
				System.out.println("Los números decimales no son válidos");
				entradaDatos2.next();
			}*/
		}
	
		public static void convertirNumeros(String numero){
			Scanner entradaDatos = new Scanner(System.in);
			
			try{
				int numero2 = Integer.parseInt(numero);
				System.out.println("Correcto!");
			}catch(NumberFormatException exe){
				System.out.println("La conversión ha fallado. Por favor ingresa SOLO NÚMEROS. " + exe.getMessage());
			}
		}
		
		public static void convertirNumeros2(String numero){
			Scanner entradaDatos =  new Scanner(System.in);
			
			if(numero.matches("\\d+")){ 
				// De esta manera: "\\d+" es esctricto y no permite números distintos de enteros positivos
				// De esta manera: "^-?\\d+$" se admiten los números negativos
				int numero2 = Integer.parseInt(numero);
			}else{
				System.out.println("Por favor ingresa SOLO NUMEROS");
			}
			
		}
		
		public static void manejarDosExcepciones(String nombreArchivo){
			try {
				FileReader fr = new FileReader(nombreArchivo);
				BufferedReader br = new BufferedReader(fr);
				
				System.out.println(br.readLine());
				br.close();
				
				File nuevoFile = new File(nombreArchivo); //De esta manera cargamos el programa
				
				System.out.println(nuevoFile.getAbsolutePath());
				
				String ruta = new File(nombreArchivo).getAbsolutePath(); //De esta manera ahorro  código
				System.out.println(ruta);
				
			}catch(FileNotFoundException e){
				System.out.println("El archivo no fue encontrado");
			}catch(IOException exe){
				System.out.println("Error de E/S" + exe.getMessage()); //NOTA no se ve de forma muy clara la diferencia entre estas dos excepciones pero es necesario controlar IOException ya que usamos un lector
			}
		}
		
	public static void main(String[] args) {
		//convertirNumeros2("-2");
		
		//validacionNumerica2();
		
		/*Scanner entradaDatos = new Scanner(System.in);
		System.out.print("Ingresa un número entero: ");
		int numero = entradaDatos.nextInt();*/
		
		manejarDosExcepciones("/home/usertar/eclipse-WorkspaceDOS/tercerTrimestre/src/excepciones01/archivo01.txt");
		
		//TODO ¿Cuál es la diferencia entre IOException y FileNotFoundException?
		
		//Exepciones propias y clásicas. Ver las palabras repetidas, ver los espacios en blanco
		//El esplit sera /n y vamos a contar los /n y de esa forma vamos midiendo la cantidad de líneas y contamos las veces que aparece una palabra
		
		//Deberemos lanzar la excepcion palabraProhibidaException
		
		/*Metemos el archivo en un array de String donde se muestre por pantalla cada una de las líneas por pantalla, al momento de pasarlo hay que convertirlo a minúscula donde ademaás deberemos compararalo con 
		 * un */
	}

}
