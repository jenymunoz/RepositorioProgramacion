package excepciones01;

public class FuncionesUtiles {
	
	public String [] separar(String cadena){
		String [] arreglo01 = cadena.split("/n");
		return arreglo01;
	}
	
	public int contarLineas(String[] arreglo01){
		int contador = 0;
		for(int i = 0; i < arreglo01.length;i++){
			contador++;
		}
		return contador;
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
