package excepciones01;

public class IntentosFallidosException extends Exception {	
	IntentosFallidosException(String mensaje){
		super(mensaje);
	}
}
