package excepciones01;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.imageio.stream.FileImageInputStream;

public class LeerArchivoBinario {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*try(FileInputStream fis = new FileInputStream("/home/usertar/eclipse-WorkspaceDOS/tercerTrimestre/src/excepciones01/archivo.dat")){
			int byteLeido;
			while((byteLeido =  fis.read())!=-1) {
				System.out.println( (char) byteLeido );
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		//------------------------------------------------------------------------------------------------------------------------------//
		try(FileOutputStream fos = new FileOutputStream("/home/usertar/eclipse-WorkspaceDOS/tercerTrimestre/src/excepciones01/archivo.dat")){
			String texto = "Hola mundito";
			fos.write(texto.getBytes());
		}catch(IOException EXE){
			EXE.printStackTrace();
		}
		
		//------------------------------------------------------------------------------------------------------------------------------//
		try(FileInputStream fis = new FileInputStream("/home/usertar/eclipse-WorkspaceDOS/tercerTrimestre/src/excepciones01/archivo.dat")){
			int byteLeido;
			while((byteLeido =  fis.read())!=-1) {
				System.out.println( (char) byteLeido );
			}
		}catch(IOException e) {
			e.printStackTrace();
		}*/
		
		//------------------------------------------------------------------------------------------------------------------------------//
		
		/*try(DataOutputStream dos =  new DataOutputStream(new FileOutputStream("/home/usertar/eclipse-WorkspaceDOS/tercerTrimestre/src/excepciones01/ar03.bin"))){
			dos.writeInt(25);
			dos.writeDouble(25.1);
			dos.writeBoolean(true);
			dos.writeUTF("Holita");
		}catch(IOException e){
			e.printStackTrace();
		}
		
		//------------------------------------------------------------------------------------------------------------------------------//
		try(DataInputStream dos = new DataInputStream(new FileInputStream("/home/usertar/eclipse-WorkspaceDOS/tercerTrimestre/src/excepciones01/ar02.bin"))){
			int numero = dos.readInt();
			double decimal = dos.readDouble();
			boolean bool = dos.readBoolean();
			String texto1 = dos.readUTF();
			
			System.out.println("Decimal" + decimal);
			System.out.println("Entero" + numero);
			System.out.println("Booleano" + bool);
			System.out.println("Texto" + texto1);
		}catch(IOException e) {
			e.printStackTrace();
		}*/
		
		//------------------------------------------------------------------------------------------------------------------------------//
		/*System.out.println();
		
		String nombreArchivo = "archivoDat.dat";
		
		try(FileOutputStream fos = new FileOutputStream(nombreArchivo)){
			byte [] datos = {65,66,67,68,69};
			fos.write(datos);
			System.out.println("Tarea realizada");
		}catch(IOException e){
			System.err.println("Error" + e.getMessage());
		}
		
		try(FileInputStream fis = new FileInputStream(nombreArchivo)){
			int byteLido;
			System.out.println("Datos del archivo");
			while((byteLido = fis.read()) != -1 ){
				System.out.println((char) byteLido + " ");
			}
			System.out.println();
		}catch(IOException e){
			System.err.print("Error");
		}
		
		System.out.println();*/
		
		
		/*System.out.println("---------------------------------------------------------------------------------------------------------");
		String archivo = "/home/usertar/eclipse-WorkspaceDOS/tercerTrimestre/src/excepciones01/archiv.bin";
			try(FileInputStream fis =  new FileInputStream(archivo)){
				int byteLeido;
				
				System.out.println("Contenido y caracteres del archivo.bin");
				
				while((byteLeido = fis.read()) != -1){
					String binario = String.format("%8s",Integer.toBinaryString(byteLeido)).replace(' ', '0');
					char caracter = (char) byteLeido;
					System.out.println(binario + "->" + caracter);
				}
			}catch(IOException e){
				System.out.println("No se puede leer el archivo" + e.getMessage());
			}
			
			System.out.println("---------------------------------------------------------------------------------------------------------");
			try(DataOutputStream dos = new DataOutputStream((new FileOutputStream("/home/usertar/eclipse-WorkspaceDOS/tercerTrimestre/src/excepciones01/archiv.bin")))){
				dos.writeInt(0);
				dos.writeDouble(0);
				dos.writeBoolean(false);
				System.out.println("Tarea realizada");
			}catch(IOException e) {
				System.out.println("El archivo no fue encontrado");
			}
			
			//Lectura de binarios
			try(DataInputStream dis = new DataInputStream(new FileInputStream("/home/usertar/eclipse-WorkspaceDOS/tercerTrimestre/src/excepciones01/archiv.bin"))){
				System.out.println("Numero entero: " + dis.readInt());
				System.out.println("Numero decimal: " + dis.readDouble());
				System.out.println("Booleano: " + dis.readBoolean());
			}catch(IOException e){
				System.out.println("Archivo no encontrado: " + e.getStackTrace());
			}
			
			System.out.println("---------------------------------------------------------------------------------------------------------");
			try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in))){
				System.out.println("Introduce tu edad:");
				int edad = Integer.parseInt(br.readLine());
				System.out.println("Tienes: " + edad + " años");
			}catch(IOException e) {
				System.out.println("Archivo no encontrado");
			}
			
			
			System.out.println("---------------------------------------------------------------------------------------------------------");*/
			
			/*Debe ingresar una clave, después deberá repetir la clave, después se guarda en un fichero, esta clave deberá tener cuatro caracteres, esta clave será guardado en un.dat
			 * y deberemos convertir los bytes a caracteres y nuevamente debe introducir la misma clave, a los tres intentos hay una excepción personalizada agotados intentos, 
			 * criptografiaPrimitiva, cuando falle mensaje de error y tercer intento fallido salta la excepcion
			 * 
			 * 
			 * TODO Podemos crear un método que se llame validar sontraseña que se encargará de confirmar si la contraseña cumple con los requisitos
			 * 
			 * */
			
			try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in))){
				ValidarContrasena.validadorContrasena();
			}catch(IOException e){
				System.out.println("Archivo no encontrado");
			}
	}

}
