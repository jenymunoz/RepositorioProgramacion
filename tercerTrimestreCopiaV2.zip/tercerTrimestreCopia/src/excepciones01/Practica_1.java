package excepciones01;
//Son excepciones verificadas
import java.util.Scanner;
import java.util.InputMismatchException;

public class Practica_1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numero = 0;
        boolean numeroValido = false;

        while (!numeroValido) {
            System.out.print("Ingresa un número entero: ");
            try {
                // Intentamos leer un número entero
                numero = scanner.nextInt();
                numeroValido = true;  // Si se ingresa un número válido, salimos del bucle
            } catch (InputMismatchException e) {
                // Esto ocurre si el tipo ingresado no es un número entero
                System.out.println("Error: No ingresaste un número entero. Por favor intenta de nuevo.");
                scanner.next();  // Limpiamos el buffer de entrada
            }
        }

        System.out.println("El número ingresado es: " + numero);
        scanner.close();
    }
}


