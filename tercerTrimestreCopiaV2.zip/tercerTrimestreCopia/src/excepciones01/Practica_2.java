package excepciones01;


import java.util.Scanner;

public class Practica_2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingresa un número: ");
        String entrada = scanner.nextLine();  // Leemos la entrada como cadena

        try {
            int numero = Integer.parseInt(entrada);  // Intentamos convertir la cadena a un número entero
            System.out.println("El número ingresado es: " + (numero + 4) );
        } catch (NumberFormatException e) {
            System.out.println("Error: La cadena ingresada no es un número válido.");
        }

        scanner.close();
    }
}
