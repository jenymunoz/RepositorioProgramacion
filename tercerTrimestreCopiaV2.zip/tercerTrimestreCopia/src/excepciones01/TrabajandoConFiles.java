package excepciones01;

import java.io.File;
import java.io.IOException;

public class TrabajandoConFiles {

	public static void main(String[] args) /*throws IOException*/ {
		/*File fichero = new File("src/fichero01.txt");
		System.out.println(fichero.exists());
		System.out.println(fichero.canRead());
		System.out.println(fichero.getPath());
		System.out.println(fichero.getAbsolutePath());
		
		fichero.getAbsolutePath();
		
		System.out.println();*/
		
		
		try{
			File nuevoArchivo = new File("fichero01.txt");
			if(nuevoArchivo.createNewFile()){
				System.out.println("Creado!");
			}else {
				System.out.println("ups!");
			}
		} catch(IOException e){
			e.printStackTrace();
		}
	}

}
