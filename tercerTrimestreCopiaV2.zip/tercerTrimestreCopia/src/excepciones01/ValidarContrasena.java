package excepciones01;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class ValidarContrasena {
	
	 public static void validadorContrasena(){
		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in))){
			
			System.out.println("Introduce una contraseña que conste de cuatro caracteres:" );
			String contrasena = String.format(br.readLine()); 
			
			while(contrasena.length() != 4){
				System.out.println("Introduce una contraseña que conste de cuatro caracteres" );
				contrasena = String.format(br.readLine());
			}
			
			System.out.println("Confirma la contraseña: ");
			String contrasenaR = String.format(br.readLine());
			if(contrasenaR.equals(contrasena)){
				
				String nombreAr = "contraseña.dat";
				try(FileOutputStream fos = new FileOutputStream(nombreAr)){
					fos.write(contrasenaR.getBytes());
				
				}
				System.out.println("Contraseña guardada");
				System.out.println("Deseas ver tu contraseña? ");
				String respuesta = String.format(br.readLine());
				if(respuesta.toLowerCase() == "si"){
					System.out.println("Esta es una prueba");
					/*try(FileInputStream fos = new FileInputStream("C:\\Users\\mello\\eclipse-workspace\\tercerTrimestreCopia\\contraseña.dat")){
						int byteLeido;
						while((byteLeido = fos.read()) != -1) {
							System.out.println( (char) byteLeido );
						}
					}*/
				}
			}else {
				int contador = 0;
				while(!contrasenaR.equals(contrasena)){
					System.out.println("Las contraseñas no conciden. Escribe la contraseña nuevamente");
					contrasenaR = String.format(br.readLine());
					contador++;
					if(contador == 3){
						throw new IntentosFallidosException("Fallo de confirmación de contraseña llegaste a tres intentos");
					}
				}
			}	
			
		}catch(IOException e){
			System.out.println("Error de entrada/salida");
		} catch (IntentosFallidosException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	 }
	
	//TODO este método puede llamar a otro método que compruebe se ambas contraseñas son iguales
	//TODO Este método puede llamar a otro método que cree el archivo.dat con la contraseña
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
