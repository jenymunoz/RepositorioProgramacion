package excepciones01;

public class Verificadas {

	    public static void main(String[] args) { 

	        // Ejemplo 1: Manejo de NullPointerException 

	        String texto = null; 

	  

	        try { 

	            System.out.println("Intentando obtener la longitud del texto..."); 

	            int longitud = obtenerLongitud(texto); 

	            System.out.println("Longitud del texto: " + longitud); 

	        } catch (NullPointerException e) { 

	            System.out.println("Error: Se ha producido un NullPointerException. La variable texto es null." + e.getStackTrace() /*Este trozo de código lo que hace es mostrar la ubicación de la excepcion*/); 

	        } finally { 

	            System.out.println("Finalizando el manejo de NullPointerException."); 

	        } 

	  

	        System.out.println("\nContinuamos con otro ejemplo...\n"); 

	  

	        // Ejemplo 2: Manejo de ArithmeticException 

	        int numerador = 10; 

	        int denominador = 0; 

	  

	        try { 

	            System.out.println("Intentando dividir " + numerador + " entre " + denominador + "..."); 

	            int resultado = dividir(numerador, denominador); 

	            System.out.println("Resultado de la división: " + resultado); 

	        } catch (ArithmeticException e) { 

	            System.out.println("Error: Se ha producido una ArithmeticException. No se puede dividir por cero."); 

	        } finally { 

	            System.out.println("Finalizando el manejo de ArithmeticException."); 

	        } 

	  

	        System.out.println("\nContinuamos con otro ejemplo...\n"); 

	  

	        // Ejemplo 3: Manejo de ArrayIndexOutOfBoundsException 

	        int[] numeros = {1, 2, 3}; 

	  

	        try { 

	            System.out.println("Intentando acceder a un índice fuera de los límites del array..."); 

	            int valor = numeros[5]; // Esto generará una excepción 

	            System.out.println("Valor obtenido: " + valor); 

	        } catch (ArrayIndexOutOfBoundsException e) { 

	            System.out.println("Error: Se ha producido una ArrayIndexOutOfBoundsException. Índice fuera de rango."); 

	        } finally { 

	            System.out.println("Finalizando el manejo de ArrayIndexOutOfBoundsException."); 

	        } 

	  

	        System.out.println("\nEl programa finalizó correctamente."); 

	    } 

	  

	    // Método para obtener la longitud de un texto 

	    public static int obtenerLongitud(String texto) { 

	        if (texto == null) { 

	            throw new NullPointerException("El texto proporcionado es null"); 

	        } 

	        return texto.length(); 

	    } 

	  

	    // Método para dividir dos números con manejo de excepción 

	    public static int dividir(int a, int b) { 

	        if (b == 0) { 

	            throw new ArithmeticException("División por cero no permitida"); 

	        } 

	        return a / b; 

	    } 

	
}

class pueba01{
	public static void main(String [] args){
		Verificadas verificar01 = new Verificadas();
	}
}
